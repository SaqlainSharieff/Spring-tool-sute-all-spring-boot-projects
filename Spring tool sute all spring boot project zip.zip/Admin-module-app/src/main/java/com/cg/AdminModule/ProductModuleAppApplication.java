package com.cg.AdminModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductModuleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductModuleAppApplication.class, args);
	}

}
