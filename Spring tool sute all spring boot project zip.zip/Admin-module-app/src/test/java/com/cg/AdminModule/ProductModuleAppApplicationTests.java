package com.cg.AdminModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductModuleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
