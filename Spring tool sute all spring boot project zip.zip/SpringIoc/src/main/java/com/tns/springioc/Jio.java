package com.tns.springioc;

public class Jio implements Sim
{
	public Jio() 
	  {
			System.out.println("Jio object is created");
		}

	public void calling() 
	{
		System.out.println("Calling using Jio sim....!");
		
	}

	public void data() 
	{
	System.out.println("Browsing using Jio sim....!");
		
	}

}
