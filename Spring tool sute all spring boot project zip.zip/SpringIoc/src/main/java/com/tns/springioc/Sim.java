package com.tns.springioc;

public interface Sim 
{
void calling();
void data();

}
