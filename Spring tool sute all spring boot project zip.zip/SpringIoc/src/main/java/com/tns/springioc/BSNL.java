package com.tns.springioc;

public class BSNL implements Sim
{
	public BSNL() {
		System.out.println("BSNL object is created");
	}

	public void calling() 
	{
		System.out.println("Calling using BSNL sim......!");
		
	}

	public void data() 
	{
		System.out.println("Browsing using BSNL sim......!");
		
	}

}
