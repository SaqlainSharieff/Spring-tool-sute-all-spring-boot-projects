package com.cg.EmployeeManagementApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootFirstApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootFirstApp1Application.class, args);
	}

}
