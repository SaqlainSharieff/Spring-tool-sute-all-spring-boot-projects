package com.cg.EmployeeManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFirstApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
