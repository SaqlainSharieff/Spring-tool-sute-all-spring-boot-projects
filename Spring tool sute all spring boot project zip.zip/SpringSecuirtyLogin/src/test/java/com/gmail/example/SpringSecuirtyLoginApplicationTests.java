package com.gmail.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecuirtyLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
