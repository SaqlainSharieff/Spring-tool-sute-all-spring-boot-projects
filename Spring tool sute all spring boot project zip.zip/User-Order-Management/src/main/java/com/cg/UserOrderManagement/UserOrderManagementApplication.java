package com.cg.UserOrderManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserOrderManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserOrderManagementApplication.class, args);
	}

}
