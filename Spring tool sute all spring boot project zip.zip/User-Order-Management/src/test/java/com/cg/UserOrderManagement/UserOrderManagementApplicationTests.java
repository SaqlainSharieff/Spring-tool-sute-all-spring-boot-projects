package com.cg.UserOrderManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserOrderManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
