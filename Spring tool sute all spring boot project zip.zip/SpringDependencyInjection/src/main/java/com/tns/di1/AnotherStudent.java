package com.tns.di1;

public class AnotherStudent 
{
private MathCheat chit;
	
	public void setChit(MathCheat chit) {
		this.chit = chit;
	}

	public void startCheating()
	{
		chit.mathCheat();
	}

}