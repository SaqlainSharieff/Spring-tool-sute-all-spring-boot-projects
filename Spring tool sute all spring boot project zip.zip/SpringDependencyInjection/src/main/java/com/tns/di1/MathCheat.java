package com.tns.di1;

public class MathCheat
{
	public MathCheat()
	{
		System.out.println("MathChet Constructor");
	}
	void mathCheat()
	{
		System.out.println("Microxerox is ready");
	}

}